-- MySQL dump 10.13  Distrib 5.6.24, for Win32 (x86)
--
-- Host: localhost    Database: travelagency
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tours`
--

DROP TABLE IF EXISTS `tours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tours` (
  `id_tour` int(11) NOT NULL AUTO_INCREMENT,
  `dateOfBeginning` varchar(30) NOT NULL,
  `dateEnd` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `numberOfNights` int(11) NOT NULL,
  `cost` int(11) NOT NULL,
  `discount` varchar(30) NOT NULL,
  `id_country` int(11) DEFAULT NULL,
  `id_typeOfTour` int(11) DEFAULT NULL,
  `id_kindOfTour` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_tour`),
  KEY `id_country_idx` (`id_country`),
  KEY `id_typeOfTour_idx` (`id_typeOfTour`),
  KEY `id_kindOfTour_idx` (`id_kindOfTour`),
  CONSTRAINT `id_country` FOREIGN KEY (`id_country`) REFERENCES `country` (`id_country`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `id_kindOfTour` FOREIGN KEY (`id_kindOfTour`) REFERENCES `kindoftour` (`id_kindOfTour`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `id_typeOfTour` FOREIGN KEY (`id_typeOfTour`) REFERENCES `typeoftour` (`id_typeOfTour`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tours`
--

LOCK TABLES `tours` WRITE;
/*!40000 ALTER TABLE `tours` DISABLE KEYS */;
INSERT INTO `tours` VALUES (1,'2016-05-20','2016-05-27','Посейдон',6,1800,'(0-25)%',4,2,2),(2,'2016-06-15','2016-06-28','HolidayTime',12,2500,'(0-30)%',1,1,1),(3,'2016-07-22','2016-07-07','Ост-Вест',3,600,'(0-5)%',3,2,3),(4,'2016-07-22','2016-08-11','Зевс',18,5500,'(0-15)%',5,2,1),(5,'2016-09-01','2016-09-14','Лагуна',13,6000,'(0-10)%',2,1,2),(16,'2016-11-25','2016-12-10','Соната',14,4300,'(0-15)%',NULL,2,1),(17,'2016-12-12','2016-12-16','Аврора',3,400,'(0-5)%',NULL,1,3);
/*!40000 ALTER TABLE `tours` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-19 17:47:31
